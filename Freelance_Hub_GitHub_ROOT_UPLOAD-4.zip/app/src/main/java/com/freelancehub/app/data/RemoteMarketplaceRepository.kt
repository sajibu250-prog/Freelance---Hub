package com.freelancehub.app.data

import com.freelancehub.app.network.SecureApiClient
import com.freelancehub.app.network.AuthenticatedApiClient
import com.freelancehub.app.security.TokenStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** Authenticated marketplace adapter. All business data stays on the server when configured. */
class RemoteMarketplaceRepository(
    private val client: SecureApiClient,
    private val tokenStore: TokenStore
) : JobsRepository, ProposalsRepository {
    private val authClient = AuthenticatedApiClient(client, tokenStore)
    override suspend fun list(query: String): Result<List<Job>> = withContext(Dispatchers.IO) {
        request { 
            val path = if (query.isBlank()) ApiContract.JOBS else "${ApiContract.JOBS}?query=${java.net.URLEncoder.encode(query.trim(), "UTF-8")}"
            val response = authClient.get(path)
            if (response.statusCode !in 200..299) error("Unable to load jobs (${response.statusCode})")
            val data = JSONObject(response.body).optJSONObject("data") ?: JSONObject()
            val items = data.optJSONArray("items") ?: JSONArray()
            (0 until items.length()).map { parseJob(items.getJSONObject(it)) }
        }
    }

    override suspend fun get(jobId: String): Result<Job> = getById(jobId)

    suspend fun getById(jobId: String): Result<Job> = withContext(Dispatchers.IO) {
        request {
            val response = authClient.get(ApiContract.JOB_BY_ID.replace("{jobId}", jobId))
            if (response.statusCode !in 200..299) error("Unable to load job (${response.statusCode})")
            val data = JSONObject(response.body).optJSONObject("data") ?: JSONObject(response.body)
            parseJob(data)
        }
    }

    override suspend fun create(job: Job): Result<Job> = withContext(Dispatchers.IO) {
        request {
            val body = JSONObject().apply {
                put("title", job.title)
                put("description", job.description)
                put("budgetMinor", parseBudgetMinor(job.budget))
                put("currency", "USD")
                put("skills", JSONArray(job.skills.split(',').map { it.trim() }.filter { it.isNotBlank() }))
            }.toString().toByteArray(Charsets.UTF_8)
            val response = authClient.post(ApiContract.JOBS, body, SecureApiClient.newIdempotencyKey())
            if (response.statusCode !in 200..299) error("Unable to publish job (${response.statusCode})")
            val data = JSONObject(response.body).optJSONObject("data") ?: JSONObject(response.body)
            parseJob(data, fallbackClient = job.client)
        }
    }

    override suspend fun submit(proposal: Proposal): Result<Proposal> = withContext(Dispatchers.IO) {
        request {
            val body = JSONObject().apply {
                put("coverLetter", proposal.coverLetter)
                put("bidMinor", parseBudgetMinor(proposal.bid))
                put("currency", "USD")
                put("deliveryDays", parseDays(proposal.delivery))
            }.toString().toByteArray(Charsets.UTF_8)
            val path = ApiContract.proposalsForJob(proposal.jobId)
            val response = authClient.post(path, body, SecureApiClient.newIdempotencyKey())
            if (response.statusCode !in 200..299) error("Unable to submit proposal (${response.statusCode})")
            proposal.copy(status = ProposalStatus.SUBMITTED)
        }
    }

    override suspend fun updateStatus(jobId: String, status: String): Result<Unit> = updateStatusByProposalId(jobId, status)

    suspend fun conversations(): Result<List<Conversation>> = withContext(Dispatchers.IO) { request {
        val response = authClient.get(ApiContract.MESSAGES)
        if (response.statusCode !in 200..299) error("Unable to load conversations (${response.statusCode})")
        val items = JSONObject(response.body).optJSONObject("data")?.optJSONArray("items") ?: JSONArray()
        (0 until items.length()).map { x -> val o=items.getJSONObject(x); Conversation(o.optString("id"),o.optString("freelancerId"),o.optString("clientId"),o.optString("lastMessage"),o.optString("lastMessageAt")) }
    }}

    suspend fun createConversation(otherUserId: String): Result<Conversation> = withContext(Dispatchers.IO) { request {
        val response=authClient.post(ApiContract.CONVERSATIONS, JSONObject().put("otherUserId",otherUserId).toString().toByteArray(Charsets.UTF_8), SecureApiClient.newIdempotencyKey())
        if(response.statusCode !in 200..299) error("Unable to start conversation (${response.statusCode})")
        val o=JSONObject(response.body).optJSONObject("data") ?: error("Invalid conversation response")
        Conversation(o.optString("id"),o.optString("freelancerId"),o.optString("clientId"))
    }}

    suspend fun messages(conversationId: String): Result<List<ChatMessage>> = withContext(Dispatchers.IO) { request {
        val response=authClient.get(ApiContract.messages(conversationId))
        if(response.statusCode !in 200..299) error("Unable to load messages (${response.statusCode})")
        val items=JSONObject(response.body).optJSONObject("data")?.optJSONArray("items") ?: JSONArray()
        (0 until items.length()).map { x -> val o=items.getJSONObject(x); ChatMessage(o.optString("id"),o.optString("senderId"),o.optString("body"),o.optString("createdAt")) }
    }}

    suspend fun sendMessage(conversationId:String, body:String): Result<ChatMessage> = withContext(Dispatchers.IO) { request {
        val response=authClient.post(ApiContract.messages(conversationId), JSONObject().put("body",body.trim()).toString().toByteArray(Charsets.UTF_8), SecureApiClient.newIdempotencyKey())
        if(response.statusCode !in 200..299) error("Unable to send message (${response.statusCode})")
        val o=JSONObject(response.body).optJSONObject("data") ?: error("Invalid message response")
        ChatMessage(o.optString("id"),o.optString("senderId"),o.optString("body"),o.optString("createdAt"))
    }}

    suspend fun notifications(): Result<List<AppNotification>> = withContext(Dispatchers.IO) { request {
        val response=authClient.get(ApiContract.NOTIFICATIONS)
        if(response.statusCode !in 200..299) error("Unable to load notifications (${response.statusCode})")
        val items=JSONObject(response.body).optJSONObject("data")?.optJSONArray("items") ?: JSONArray()
        (0 until items.length()).map { x -> val o=items.getJSONObject(x); AppNotification(o.optString("id"),o.optString("type"),o.optString("title"),o.optString("body"),o.optBoolean("read"),o.optString("createdAt")) }
    }}

    suspend fun markNotificationRead(id:String): Result<Unit> = withContext(Dispatchers.IO) { request {
        val response=authClient.post(ApiContract.notificationRead(id), ByteArray(0))
        if(response.statusCode !in 200..299 && response.statusCode != 204) error("Unable to mark notification read (${response.statusCode})")
        Unit
    }}

    suspend fun myProposals(): Result<List<Proposal>> = withContext(Dispatchers.IO) { request {
        val response = authClient.get(ApiContract.MY_PROPOSALS)
        if (response.statusCode !in 200..299) error("Unable to load your proposals (${response.statusCode})")
        val items = JSONObject(response.body).optJSONObject("data")?.optJSONArray("items") ?: JSONArray()
        (0 until items.length()).map { i ->
            val o = items.getJSONObject(i)
            val currency = o.optString("currency", "USD")
            val bid = String.format(java.util.Locale.US, "%s %.2f", currency, o.optLong("bidMinor") / 100.0)
            Proposal(
                jobId = o.optString("jobId"), coverLetter = o.optString("coverLetter"), bid = bid,
                delivery = "${o.optInt("deliveryDays")} days",
                status = o.optString("status", "SUBMITTED").replaceFirstChar { it.titlecase() },
                createdAt = 0L, proposalId = o.optString("id"), freelancerId = "", jobTitle = o.optString("jobTitle")
            )
        }
    }}

    suspend fun myJobs(): Result<List<Job>> = withContext(Dispatchers.IO) { request {
        val response = authClient.get(ApiContract.MY_JOBS)
        if (response.statusCode !in 200..299) error("Unable to load your jobs (${response.statusCode})")
        val items = JSONObject(response.body).optJSONObject("data")?.optJSONArray("items") ?: JSONArray()
        (0 until items.length()).map { i -> parseJob(items.getJSONObject(i), fallbackClient = "You") }
    }}

    suspend fun updateJobStatus(jobId: String, status: String): Result<Unit> = withContext(Dispatchers.IO) { request {
        val body = JSONObject().put("status", status.uppercase()).toString().toByteArray(Charsets.UTF_8)
        val response = authClient.patch(ApiContract.jobStatus(jobId), body)
        if (response.statusCode !in 200..299) error("Unable to update job status (${response.statusCode})")
        Unit
    }}

    suspend fun proposalsForJob(jobId: String): Result<List<Proposal>> = withContext(Dispatchers.IO) { request {
        val response = authClient.get(ApiContract.proposalsForJob(jobId))
        if (response.statusCode !in 200..299) error("Unable to load proposals (${response.statusCode})")
        val items = JSONObject(response.body).optJSONObject("data")?.optJSONArray("items") ?: JSONArray()
        (0 until items.length()).map { i -> val o=items.getJSONObject(i); Proposal(
            jobId=jobId, coverLetter=o.optString("coverLetter"),
            bid=String.format(java.util.Locale.US, "USD %.2f", o.optLong("bidMinor")/100.0),
            delivery="${o.optInt("deliveryDays")} days", status=o.optString("status", "SUBMITTED").replaceFirstChar { it.titlecase() },
            createdAt=0L, proposalId=o.optString("id"), freelancerId=o.optString("freelancerId")
        ) }
    }}

    suspend fun updateStatusByProposalId(proposalId: String, status: String): Result<Unit> = withContext(Dispatchers.IO) {
        request {
            val body = JSONObject().put("status", status.uppercase()).toString().toByteArray(Charsets.UTF_8)
            val response = authClient.patch(ApiContract.proposal(proposalId), body)
            if (response.statusCode !in 200..299) error("Unable to update proposal (${response.statusCode})")
            Unit
        }
    }

    suspend fun getProfile(): Result<UserProfile> = withContext(Dispatchers.IO) { request {
        val response = authClient.get(ApiContract.PROFILE)
        if (response.statusCode !in 200..299) error("Unable to load profile (${response.statusCode})")
        val o = JSONObject(response.body).optJSONObject("data") ?: error("Invalid profile response")
        val role = runCatching { UserRole.valueOf(o.optString("role", "FREELANCER").uppercase()) }.getOrDefault(UserRole.FREELANCER)
        val skills = o.optJSONArray("skills")?.let { a -> (0 until a.length()).joinToString(", ") { a.optString(it) } } ?: o.optString("skills", "")
        val portfolio = o.optJSONArray("portfolio")?.let { a -> (0 until a.length()).map { i -> val x=a.getJSONObject(i); PortfolioItem(x.optString("title"),x.optString("description"),x.optString("url"),x.optJSONArray("skills")?.let { sk -> (0 until sk.length()).joinToString(", "){sk.optString(it)} } ?: x.optString("skills")) } } ?: emptyList()
        UserProfile(o.optString("displayName"), o.optString("email"), o.optString("bio"), skills, role, portfolio)
    }}

    suspend fun updateProfile(profile: UserProfile): Result<UserProfile> = withContext(Dispatchers.IO) { request {
        val skills = JSONArray(profile.skills.split(",").map { it.trim() }.filter { it.isNotBlank() })
        val portfolio = JSONArray(profile.portfolio.take(20).map { item -> JSONObject().put("title",item.title.trim()).put("description",item.description.trim()).put("url",item.url.trim()).put("skills",JSONArray(item.skills.split(",").map { it.trim() }.filter { it.isNotBlank() })) })
        val body = JSONObject().put("displayName", profile.name.trim()).put("bio", profile.bio.trim()).put("skills", skills).put("portfolio", portfolio).toString().toByteArray(Charsets.UTF_8)
        val response = authClient.patch(ApiContract.PROFILE, body)
        if (response.statusCode !in 200..299) error("Unable to update profile (${response.statusCode})")
        val o = JSONObject(response.body).optJSONObject("data") ?: error("Invalid profile response")
        val role = runCatching { UserRole.valueOf(o.optString("role", profile.role.name).uppercase()) }.getOrDefault(profile.role)
        val returnedSkills = o.optJSONArray("skills")?.let { a -> (0 until a.length()).joinToString(", ") { a.optString(it) } } ?: profile.skills
        val returnedPortfolio = o.optJSONArray("portfolio")?.let { a -> (0 until a.length()).map { i -> val x=a.getJSONObject(i); PortfolioItem(x.optString("title"),x.optString("description"),x.optString("url"),x.optJSONArray("skills")?.let { sk -> (0 until sk.length()).joinToString(", "){sk.optString(it)} } ?: x.optString("skills")) } } ?: profile.portfolio
        UserProfile(o.optString("displayName", profile.name), o.optString("email", profile.email), o.optString("bio", profile.bio), returnedSkills, role, returnedPortfolio)
    }}

    private fun parseJob(x: JSONObject, fallbackClient: String = "Client"): Job {
        val skills = x.optJSONArray("skills")?.let { a -> (0 until a.length()).joinToString(", ") { a.optString(it) } }
            ?: x.optString("skills", "")
        val budgetMinor = x.optLong("budgetMinor", 0L)
        val currency = x.optString("currency", "USD")
        return Job(
            id = x.optString("id"),
            clientId = x.optString("clientId"),
            title = x.optString("title"),
            client = x.optString("clientName", x.optString("client", fallbackClient)),
            budget = "$currency ${"%.2f".format(java.util.Locale.US, budgetMinor / 100.0)}",
            skills = skills,
            description = x.optString("description"),
            remote = true,
            status = x.optString("status", JobStatus.OPEN),
            createdAt = x.optString("createdAt").let { it.hashCode().toLong() },
            proposalCount = x.optInt("proposalCount", 0)
        )
    }

    private fun parseBudgetMinor(value: String): Long = value.filter { it.isDigit() || it == '.' }.toDoubleOrNull()?.times(100)?.toLong()
        ?: error("Budget must be numeric")

    private fun parseDays(value: String): Int = value.filter { it.isDigit() }.toIntOrNull()?.coerceIn(1, 365) ?: error("Delivery time must contain days")

    private inline fun <T> request(block: () -> T): Result<T> = runCatching { block() }
}
