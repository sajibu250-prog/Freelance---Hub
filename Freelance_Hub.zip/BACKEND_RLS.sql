-- SUPABASE/POSTGRES AUTH-SPECIFIC RLS BASELINE
-- Apply this file only in an environment that provides auth.uid().
-- Do NOT run this file against a plain PostgreSQL container without an auth schema.

ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE proposals ENABLE ROW LEVEL SECURITY;

CREATE POLICY users_select_public_profile ON users FOR SELECT USING (true);
CREATE POLICY users_update_self ON users FOR UPDATE USING (id = auth.uid()) WITH CHECK (id = auth.uid());
CREATE POLICY users_insert_self ON users FOR INSERT WITH CHECK (id = auth.uid());

CREATE POLICY jobs_read_open ON jobs FOR SELECT USING (status = 'OPEN' OR client_id = auth.uid());
CREATE POLICY jobs_insert_client_only ON jobs FOR INSERT WITH CHECK (client_id = auth.uid());
CREATE POLICY jobs_update_owner ON jobs FOR UPDATE USING (client_id = auth.uid()) WITH CHECK (client_id = auth.uid());
CREATE POLICY jobs_delete_owner ON jobs FOR DELETE USING (client_id = auth.uid());

CREATE POLICY proposals_read_participants ON proposals FOR SELECT USING (
  freelancer_id = auth.uid() OR EXISTS (SELECT 1 FROM jobs j WHERE j.id = job_id AND j.client_id = auth.uid())
);
CREATE POLICY proposals_insert_freelancer ON proposals FOR INSERT WITH CHECK (freelancer_id = auth.uid());
CREATE POLICY proposals_update_participants ON proposals FOR UPDATE USING (
  freelancer_id = auth.uid() OR EXISTS (SELECT 1 FROM jobs j WHERE j.id = job_id AND j.client_id = auth.uid())
);
