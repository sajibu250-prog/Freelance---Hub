# Freelance Hub v1.18

- Added a provider-neutral HTTPS API transport foundation with request IDs, bearer-token support, timeouts, and idempotency-key support for POST requests.
- Hardened Play update prompting so it does not repeatedly trigger during the same activity session.
- Preserved interrupted-update resume behavior.
- Added build/release guidance and repository hygiene rules for secrets and generated files.
- Version: 0.18.0 (versionCode 18).

## Verification status

Source-level review completed in this environment. APK/AAB compilation remains unverified because Android SDK and Gradle wrapper are not installed in the current environment.
