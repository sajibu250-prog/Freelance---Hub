# Freelance Hub — Authentication & Session Security Contract

## Client rules
- Never embed database passwords, JWT signing keys, payment secrets, or admin credentials in the APK.
- Production API endpoints must use HTTPS.
- Access tokens are stored with Android Keystore-backed AES/GCM in `TokenStore`.
- The client should treat HTTP 401 as an expired session and refresh/re-authenticate through the API.
- Do not log access tokens, passwords, authorization headers, or full request bodies containing secrets.

## Server rules
- Passwords must be hashed with a modern password hashing scheme (Argon2id preferred; bcrypt/scrypt are acceptable alternatives when configured correctly). Never store plaintext passwords.
- Rate-limit login, signup, password reset, and token refresh endpoints.
- Rotate refresh tokens and revoke them on logout or suspected compromise.
- Validate email, password policy, role, and all user-generated text server-side; client validation is only a UX layer.
- Return generic authentication failure messages to reduce account enumeration.
- Enforce authorization from the authenticated subject (`auth.uid()`/equivalent), not from client-supplied owner IDs.
- Record a request ID for security/audit correlation without storing unnecessary personal data.

## Required production endpoints
- `POST /v1/auth/signup`
- `POST /v1/auth/login`
- `POST /v1/auth/refresh`
- `POST /v1/auth/logout`

The Android UI currently contains a local/demo login flow. It must not be presented as production authentication until these endpoints are connected and end-to-end tested.
