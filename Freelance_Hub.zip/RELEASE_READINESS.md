# Release readiness gates

- [ ] Build with a pinned Gradle wrapper and Android SDK.
- [ ] Run unit tests and instrumentation/UI tests on supported API levels.
- [ ] Configure a real production backend over HTTPS.
- [ ] Configure authentication and server-side authorization.
- [ ] Configure database migrations and backups.
- [ ] Configure Play App Signing / release signing.
- [ ] Publish an internal testing build before production.
- [ ] Verify in-app update on an older installed version.
- [ ] Verify mandatory update behavior.
- [ ] Verify rollback strategy for backend changes.
- [ ] Verify privacy policy, account deletion, data export/retention and abuse reporting flows.
