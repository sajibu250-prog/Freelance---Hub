# Build environment gate

Required before generating a release APK/AAB:

1. Gradle wrapper committed to the repository (`gradlew`, `gradlew.bat`, `gradle/wrapper/*`).
2. Android SDK with compile/target SDK 35 installed.
3. JDK 17 toolchain available to Gradle.
4. Run `./gradlew :app:assembleDebug` and test tasks.
5. For release, configure Play App Signing and generate an AAB; never commit signing secrets.
