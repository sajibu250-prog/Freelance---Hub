package com.freelancehub.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.foundation.background
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.freelancehub.app.data.*
import com.freelancehub.app.update.PlayUpdateManager
import com.freelancehub.app.network.SecureApiClient
import com.freelancehub.app.security.TokenStore

private val jobs=listOf(
    Job("demo-1","Build a modern business website","Acme Studio","$300–$600","WordPress, UI/UX","Responsive website for a growing business."),
    Job("demo-2","Social media content designer","Nova Brand","$100–$250","Canva, Photoshop","Create a monthly pack of social media creatives."),
    Job("demo-3","Android app UI implementation","TechWorks","$500–$900","Kotlin, Compose","Implement polished Android screens from a design system."),
    Job("demo-4","SEO content writer","Global Media","$150–$400","SEO, Writing","Write optimized English articles for international readers.")
)
private val courses=listOf("Freelancing Fundamentals" to "Free","Digital Marketing Masterclass" to "$29","AI Tools for Freelancers" to "$19")
class MainActivity:ComponentActivity(){
    private lateinit var playUpdateManager: PlayUpdateManager
    private lateinit var tokenStore: TokenStore
    private var authRepository: RemoteAuthRepository? = null
    override fun onCreate(b:Bundle?){
        super.onCreate(b)
        playUpdateManager = PlayUpdateManager(this)
        tokenStore = TokenStore(this)
        val config = RuntimeBackendConfig.fromBuildConfig()
        if (config.isConfigured() && config.validate().isEmpty()) authRepository = RemoteAuthRepository(SecureApiClient(config), tokenStore)
        setContent{FreelanceHubApp(AppRepository(this), config, tokenStore)}
    }
    override fun onResume(){
        super.onResume()
        if (::playUpdateManager.isInitialized) playUpdateManager.resumeIfInterrupted()
    }
    override fun onStart(){
        super.onStart()
        if (::playUpdateManager.isInitialized) playUpdateManager.checkForUpdate()
        if (::tokenStore.isInitialized && authRepository != null && tokenStore.readRefreshToken() != null && !tokenStore.isAccessTokenFresh(120)) {
            lifecycleScope.launch { authRepository?.refresh() }
        }
    }
}
@Composable fun FreelanceHubApp(repo:AppRepository, config:BackendConfig, tokenStore:TokenStore){
    var loggedIn by remember{mutableStateOf(repo.isLoggedIn() && tokenStore.readAccessToken() != null)}
    val client = remember(config.baseUrl, config.projectId, config.environment) {
        if (config.isConfigured() && config.validate().isEmpty()) SecureApiClient(config) else null
    }
    val remote = remember(client) { client?.let { RemoteAuthRepository(it, tokenStore) } }
    val marketplace = remember(client) { client?.let { RemoteMarketplaceRepository(it, tokenStore) } }
    if(!loggedIn) LoginScreen(remote, repo, { loggedIn=true })
    else MainShell(repo, marketplace, tokenStore){
        if(remote != null) {
            repo.setLoggedIn(false)
            tokenStore.clear()
        } else repo.setLoggedIn(false)
        loggedIn=false
    }
}
@Composable fun LoginScreen(remote:RemoteAuthRepository?, repo:AppRepository, onSuccess:()->Unit){
    var signup by remember{mutableStateOf(false)}; var name by remember{mutableStateOf("")}; var email by remember{mutableStateOf("")}; var pass by remember{mutableStateOf("")}; var error by remember{mutableStateOf<String?>(null)}; var busy by remember{mutableStateOf(false)}
    val scope=rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(28.dp),verticalArrangement=Arrangement.Center){Text("Freelance Hub",style=MaterialTheme.typography.headlineLarge);Text("Global freelance marketplace",style=MaterialTheme.typography.bodyLarge);Spacer(Modifier.height(24.dp));
        if(signup){OutlinedTextField(name,{name=it},label={Text("Full name")},modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(10.dp))};
        OutlinedTextField(email,{email=it},label={Text("Email")},modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(10.dp));
        OutlinedTextField(pass,{pass=it},label={Text("Password")},visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth());
        error?.let{Text(it,color=MaterialTheme.colorScheme.error)}; Spacer(Modifier.height(18.dp));
        Button(onClick={scope.launch{busy=true;error=null;val req=AuthRequest(email,pass,"FREELANCER",name.takeIf{signup});val result=if(remote==null)Result.success(AuthResponse("local-demo","local","FREELANCER")) else if(signup)remote.signUp(req) else remote.signIn(req);result.onSuccess{repo.setLoggedIn(true);repo.saveProfile(UserProfile(name,email,role=UserRole.FREELANCER));onSuccess()}.onFailure{error=it.message ?: "Authentication failed"};busy=false}},enabled=!busy&&Validation.email(email)&&Validation.password(pass),modifier=Modifier.fillMaxWidth()){Text(if(busy)"Please wait…" else if(signup)"Create account" else "Continue")};
        TextButton(onClick={signup=!signup;error=null}){Text(if(signup)"Already have an account? Sign in" else "Create a new account")}
    }
}
@Composable fun MainShell(repo:AppRepository, marketplace:RemoteMarketplaceRepository?, tokenStore:TokenStore, logout:()->Unit){
    var tab by remember{mutableStateOf(0)}
    var selected by remember{mutableStateOf<Job?>(null)}
    var proposal by remember{mutableStateOf<Job?>(null)}
    var editing by remember{mutableStateOf(false)}
    var role by remember{mutableStateOf(repo.profile().role)}
    var showPostJob by remember{mutableStateOf(false)}
    var showNotifications by remember{mutableStateOf(false)}
    var selectedConversation by remember{mutableStateOf<Conversation?>(null)}
    var proposalsJob by remember{mutableStateOf<Job?>(null)}
    var myProposals by remember{mutableStateOf<List<Proposal>>(emptyList())}
    var myProposalsLoading by remember{mutableStateOf(false)}
    var myJobs by remember{mutableStateOf<List<Job>>(emptyList())}
    var myJobsLoading by remember{mutableStateOf(false)}
    var myJobsError by remember{mutableStateOf<String?>(null)}
    var unreadNotifications by remember{mutableStateOf(0)}
    var count by remember{mutableStateOf(repo.proposals().size)}
    val scope = rememberCoroutineScope()
    var submitError by remember{mutableStateOf<String?>(null)}
    val userId = remember { decodeJwtSubject(tokenStore) }
    LaunchedEffect(marketplace, role) {
        if (marketplace != null) {
            marketplace.getProfile().onSuccess { repo.saveProfile(it); role=it.role }
            marketplace.notifications().onSuccess { unreadNotifications=it.count { n -> !n.read } }
            if (role == UserRole.FREELANCER) {
                myProposalsLoading=true
                marketplace.myProposals().onSuccess { myProposals=it }
                myProposalsLoading=false
            } else {
                myJobsLoading=true; myJobsError=null
                marketplace.myJobs().onSuccess { myJobs=it }.onFailure { myJobsError=it.message ?: "Unable to load your jobs" }
                myJobsLoading=false
            }
        }
    }
    Scaffold(
        topBar={ if(!showNotifications && selectedConversation==null) TopAppBar(
            title={Text("Freelance Hub")},
            actions={ Row(verticalAlignment=Alignment.CenterVertically){ if(unreadNotifications>0) Text(unreadNotifications.toString(),style=MaterialTheme.typography.labelMedium,modifier=Modifier.padding(end=2.dp)); IconButton(onClick={showNotifications=true}){Icon(Icons.Default.Notifications,"Notifications")} } }
        ) },
        bottomBar={ if(!showNotifications && selectedConversation==null) NavigationBar{listOf("Home","Jobs","Courses","Messages","Profile").forEachIndexed{i,n->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Icon(listOf(Icons.Default.Home,Icons.Default.Work,Icons.Default.School,Icons.Default.Chat,Icons.Default.Person)[i],n)},label={Text(n)})}}}
    ){p->
        Box(Modifier.padding(p)){when{
            showNotifications->NotificationsScreen(marketplace,{showNotifications=false},{unreadNotifications=0})
            selectedConversation!=null->ChatScreen(marketplace,selectedConversation!!,userId,{selectedConversation=null})
            proposalsJob!=null->ClientProposalsScreen(marketplace,proposalsJob!!,{proposalsJob=null})
            proposal!=null->ProposalScreen(proposal!!,{proposal=null}, onSubmit={ pr ->
                submitError = null
                if (marketplace != null) scope.launch { marketplace.submit(pr).onSuccess { repo.addProposal(pr); count++; proposal=null }.onFailure { submitError=it.message ?: "Unable to submit proposal" } }
                else { repo.addProposal(pr); count++; proposal=null }
            }, error=submitError)
            selected!=null->JobDetails(selected!!,{selected=null},{proposal=selected},
                message={ job -> if(marketplace!=null && job.clientId.isNotBlank()) scope.launch { marketplace.createConversation(job.clientId).onSuccess{selectedConversation=it}.onFailure{submitError=it.message} } },
                viewProposals={ job -> proposalsJob=job })
            showPostJob->PostJobScreen({showPostJob=false}){ job ->
                if (marketplace != null) scope.launch { marketplace.create(job).onSuccess { repo.saveJob(it); showPostJob=false }.onFailure { submitError=it.message ?: "Unable to publish job" } }
                else { repo.saveJob(job); showPostJob=false }
            }
            editing->ProfileEditor(repo, marketplace, {role=repo.profile().role;editing=false})
            tab==0->HomeScreen(role, myProposals, myProposalsLoading, myJobs, myJobsLoading, myJobsError, { if(role==UserRole.CLIENT)showPostJob=true })
            tab==1->JobsScreen(repo,role,marketplace,{selected=it}){showPostJob=true}
            tab==2->CoursesScreen()
            tab==3->MessagesScreen(marketplace,userId,{selectedConversation=it})
            else->ProfileScreen(repo,{editing=true},{logout()})
        }}
    }
}

private fun decodeJwtSubject(tokenStore:TokenStore): String {
    return try {
        val token = tokenStore.readAccessToken() ?: return ""
        val payload=token.split('.')[1].replace('-','+').replace('_','/')
        val padded=payload.padEnd((payload.length+3)/4*4,'=')
        JSONObject(String(android.util.Base64.decode(padded,android.util.Base64.DEFAULT),Charsets.UTF_8)).optString("sub")
    } catch(_:Exception){ "" }
}

@Composable fun HomeScreen(role:UserRole, myProposals:List<Proposal>, loading:Boolean, myJobs:List<Job>, myJobsLoading:Boolean, myJobsError:String?, onPostJob:()->Unit){
    LazyColumn(Modifier.fillMaxSize().padding(20.dp)){
        item{
            Text("Welcome to Freelance Hub",style=MaterialTheme.typography.headlineMedium)
            Text(if(role==UserRole.FREELANCER) "Find work globally. Track your proposals." else "Post projects globally and manage proposals.",style=MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(18.dp))
            if(role==UserRole.CLIENT){
                Button(onClick=onPostJob,modifier=Modifier.fillMaxWidth()){Text("Post a job")}
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text("My Jobs",style=MaterialTheme.typography.titleLarge,modifier=Modifier.weight(1f));Text("${myJobs.size}",style=MaterialTheme.typography.labelLarge)}
                if(myJobsLoading) LinearProgressIndicator(Modifier.fillMaxWidth())
                myJobsError?.let { Text(it,color=MaterialTheme.colorScheme.error,modifier=Modifier.padding(vertical=6.dp)) }
                if(!myJobsLoading && myJobs.isEmpty()) Text("You have not posted any jobs yet.",modifier=Modifier.padding(vertical=12.dp))
            }
            else {
                Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text("My Proposals",style=MaterialTheme.typography.titleLarge,modifier=Modifier.weight(1f));Text("${myProposals.size}",style=MaterialTheme.typography.labelLarge)}
                Spacer(Modifier.height(8.dp))
                if(loading) LinearProgressIndicator(Modifier.fillMaxWidth())
                if(!loading && myProposals.isEmpty()) Text("You have not submitted any proposals yet.",modifier=Modifier.padding(vertical=12.dp))
            }
        }
        if(role==UserRole.CLIENT) items(myJobs){j->
            ElevatedCard(Modifier.fillMaxWidth().padding(vertical=5.dp)){
                Column(Modifier.padding(16.dp)){
                    Text(j.title,style=MaterialTheme.typography.titleMedium)
                    Text("Budget: ${j.budget}")
                    Text("${j.skills.ifBlank { "No skills specified" }}")
                    Text("Status: ${j.status}")
                    Text("Proposals: ${j.proposalCount}")
                    if (marketplace != null && j.clientId.isNotBlank()) {
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            val next = if (j.status.equals("OPEN", true) || j.status == JobStatus.OPEN) "PAUSED" else "OPEN"
                            OutlinedButton(onClick={scope.launch { marketplace.updateJobStatus(j.id,next).onSuccess { updated -> myJobs=myJobs.map { if(it.id==j.id) it.copy(status=if(next=="OPEN") JobStatus.OPEN else JobStatus.PAUSED) else it } }.onFailure { myJobsError=it.message ?: "Unable to update job" } }}) { Text(if(next=="OPEN") "Reopen" else "Pause") }
                            if (!j.status.equals("CLOSED", true)) OutlinedButton(onClick={scope.launch { marketplace.updateJobStatus(j.id,"CLOSED").onSuccess { myJobs=myJobs.map { if(it.id==j.id) it.copy(status=JobStatus.CLOSED) else it } }.onFailure { myJobsError=it.message ?: "Unable to close job" } }}) { Text("Close") }
                        }
                    }
                }
            }
        }
        if(role==UserRole.FREELANCER) items(myProposals){p->
            ElevatedCard(Modifier.fillMaxWidth().padding(vertical=5.dp)){
                Column(Modifier.padding(16.dp)){
                    Text(if(p.jobTitle.isBlank()) "My proposal" else p.jobTitle,style=MaterialTheme.typography.titleMedium)
                    Text(p.coverLetter.take(70).let { if(p.coverLetter.length>70) "$it…" else it })
                    Text("Bid: ${p.bid} • ${p.delivery}")
                    Text("Status: ${p.status}")
                }
            }
        }
        item{
            Spacer(Modifier.height(12.dp)); Text("Quick actions",style=MaterialTheme.typography.titleLarge);
        }
        items(listOf("Find freelance jobs","Learn practical skills","Build your portfolio","Explore Premium")){ElevatedCard(Modifier.fillMaxWidth().padding(vertical=5.dp)){Text(it,Modifier.padding(18.dp))}}
    }
}
@Composable fun JobsScreen(repo:AppRepository,role:UserRole,marketplace:RemoteMarketplaceRepository?,open:(Job)->Unit,post:()->Unit){
    var query by remember{mutableStateOf("")}
    var remoteJobs by remember{mutableStateOf<List<Job>?>(null)}
    var loading by remember{mutableStateOf(false)}
    var error by remember{mutableStateOf<String?>(null)}
    val scope=rememberCoroutineScope()
    LaunchedEffect(marketplace, query) {
        if (marketplace != null) {
            loading=true; error=null
            marketplace.list(query).onSuccess { remoteJobs=it }.onFailure { error=it.message ?: "Unable to load jobs" }
            loading=false
        }
    }
    val all=(remoteJobs ?: jobs) + repo.savedJobs()
    val filtered=all.distinctBy{it.id}.filter{it.title.contains(query,true)||it.skills.contains(query,true)||it.client.contains(query,true)}
    Column(Modifier.fillMaxSize().padding(16.dp)){
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Jobs",style=MaterialTheme.typography.headlineSmall);if(role==UserRole.CLIENT)Button(onClick=post){Text("Post job")}}
        Spacer(Modifier.height(8.dp));OutlinedTextField(query,{query=it},label={Text("Search jobs, skills or clients")},modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(8.dp))
        if(loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        error?.let { Text(it,color=MaterialTheme.colorScheme.error,modifier=Modifier.padding(vertical=6.dp)) }
        LazyColumn{items(filtered){j->ElevatedCard(onClick={open(j)},modifier=Modifier.fillMaxWidth().padding(vertical=6.dp)){Column(Modifier.padding(16.dp)){Text(j.title,style=MaterialTheme.typography.titleMedium);Text(j.client);Text("Budget: ${j.budget}");Text(j.skills);Text(if(j.remote)"Remote • Global" else "On-site")}}}}
    }
}

@Composable fun PostJobScreen(back:()->Unit,onSave:(Job)->Unit){
    var title by remember{mutableStateOf("")};var client by remember{mutableStateOf("")};var budget by remember{mutableStateOf("")};var skills by remember{mutableStateOf("")};var desc by remember{mutableStateOf("")};var error by remember{mutableStateOf(false)}
    Column(Modifier.fillMaxSize().padding(20.dp)){Text("Post a job",style=MaterialTheme.typography.headlineSmall);Spacer(Modifier.height(12.dp));
    OutlinedTextField(title,{title=it},label={Text("Job title")},modifier=Modifier.fillMaxWidth());OutlinedTextField(client,{client=it},label={Text("Client / company")},modifier=Modifier.fillMaxWidth());OutlinedTextField(budget,{budget=it},label={Text("Budget (USD)")},modifier=Modifier.fillMaxWidth());OutlinedTextField(skills,{skills=it},label={Text("Skills")},modifier=Modifier.fillMaxWidth());
        OutlinedTextField(desc,{desc=it},label={Text("Description")},minLines=4,modifier=Modifier.fillMaxWidth());if(error)Text("Complete all fields.",color=MaterialTheme.colorScheme.error);Spacer(Modifier.height(12.dp));Button(onClick={if(listOf(title,client,budget,skills,desc).all{it.isNotBlank()})onSave(Job("local-${System.currentTimeMillis()}",title,client,budget,skills,desc))else error=true},modifier=Modifier.fillMaxWidth()){Text("Publish job")};TextButton(onClick=back){Text("Cancel")}}
}

@Composable fun JobDetails(j:Job,back:()->Unit,apply:()->Unit,message:(Job)->Unit,viewProposals:(Job)->Unit){Column(Modifier.fillMaxSize().padding(20.dp)){Text(j.title,style=MaterialTheme.typography.headlineSmall);Text("Client: ${j.client}");Text("Budget: ${j.budget}");Text("Skills: ${j.skills}");Text(j.description);Text(if(j.remote)"Remote • Global" else "On-site");Spacer(Modifier.height(20.dp));Button(onClick=apply,modifier=Modifier.fillMaxWidth()){Text("Submit proposal")}; if(j.clientId.isNotBlank()) { OutlinedButton(onClick={message(j)},modifier=Modifier.fillMaxWidth()){Text("Message client")}; OutlinedButton(onClick={viewProposals(j)},modifier=Modifier.fillMaxWidth()){Text("View proposals")}}; TextButton(onClick=back){Text("Back")}}}
@Composable fun ProposalScreen(j:Job,back:()->Unit,onSubmit:(Proposal)->Unit,error:String?){var letter by remember{mutableStateOf("")};var bid by remember{mutableStateOf("")};var delivery by remember{mutableStateOf("")};var validationError by remember{mutableStateOf(false)};Column(Modifier.fillMaxSize().padding(20.dp)){Text("Proposal",style=MaterialTheme.typography.headlineSmall);Text(j.title);Spacer(Modifier.height(12.dp));OutlinedTextField(letter,{letter=it},label={Text("Cover letter")},minLines=5,modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(8.dp));OutlinedTextField(bid,{bid=it},label={Text("Your bid (USD)")},modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(8.dp));OutlinedTextField(delivery,{delivery=it},label={Text("Delivery time (days)")},modifier=Modifier.fillMaxWidth());if(validationError)Text("Complete all fields.",color=MaterialTheme.colorScheme.error);error?.let{Text(it,color=MaterialTheme.colorScheme.error)};Spacer(Modifier.height(12.dp));Button(onClick={if(letter.isNotBlank()&&bid.isNotBlank()&&delivery.isNotBlank())onSubmit(Proposal(j.id,letter,bid,delivery))else validationError=true},modifier=Modifier.fillMaxWidth()){Text("Send proposal")};TextButton(onClick=back){Text("Cancel")}}}
@Composable fun ClientProposalsScreen(marketplace:RemoteMarketplaceRepository?,job:Job,back:()->Unit){
    var items by remember{mutableStateOf<List<Proposal>>(emptyList())}; var error by remember{mutableStateOf<String?>(null)}; var loading by remember{mutableStateOf(true)}; var filter by remember{mutableStateOf("ALL")}; val scope=rememberCoroutineScope()
    suspend fun load(){ if(marketplace==null){loading=false;return}; loading=true; error=null; marketplace.proposalsForJob(job.id).onSuccess{items=it}.onFailure{error=it.message ?: "Unable to load proposals"}; loading=false }
    LaunchedEffect(marketplace,job.id){load()}
    val visible=items.filter{filter=="ALL"||it.status.uppercase()==filter}
    Column(Modifier.fillMaxSize().padding(16.dp)){
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){IconButton(onClick=back){Icon(Icons.Default.ArrowBack,"Back")};Column(Modifier.weight(1f)){Text("Proposals",style=MaterialTheme.typography.titleLarge);Text(job.title,style=MaterialTheme.typography.bodyMedium)};IconButton(onClick={scope.launch{load()}}){Icon(Icons.Default.Refresh,"Refresh")}}
        Spacer(Modifier.height(8.dp));
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp),modifier=Modifier.fillMaxWidth()){listOf("ALL","SUBMITTED","SHORTLISTED","ACCEPTED","REJECTED").forEach{status->FilterChip(selected=filter==status,onClick={filter=status},label={Text(if(status=="ALL")"All" else status.lowercase().replaceFirstChar{it.titlecase()})})}}
        Text("${items.size} total • ${items.count{it.status==ProposalStatus.ACCEPTED}} accepted • ${items.count{it.status==ProposalStatus.SHORTLISTED}} shortlisted",style=MaterialTheme.typography.bodySmall,modifier=Modifier.padding(vertical=6.dp))
        if(loading)LinearProgressIndicator(Modifier.fillMaxWidth()); error?.let{Text(it,color=MaterialTheme.colorScheme.error)}
        if(!loading&&visible.isEmpty())Text(if(items.isEmpty())"No proposals yet." else "No proposals match this filter.",Modifier.padding(top=16.dp))
        LazyColumn{items(visible){p->ElevatedCard(Modifier.fillMaxWidth().padding(vertical=6.dp)){Column(Modifier.padding(16.dp)){Text("Freelancer proposal",style=MaterialTheme.typography.titleMedium);Text("Bid: ${p.bid}");Text("Delivery: ${p.delivery}");Text(p.coverLetter);Text("Status: ${p.status}");Spacer(Modifier.height(8.dp));Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(enabled=p.proposalId.isNotBlank()&&p.status!=ProposalStatus.ACCEPTED,onClick={scope.launch{marketplace?.updateStatusByProposalId(p.proposalId,"ACCEPTED")?.onSuccess{items=items.map{if(it.proposalId==p.proposalId)it.copy(status=ProposalStatus.ACCEPTED)else it}}?.onFailure{error=it.message}}}){Text("Accept")};OutlinedButton(enabled=p.proposalId.isNotBlank()&&p.status==ProposalStatus.SUBMITTED,onClick={scope.launch{marketplace?.updateStatusByProposalId(p.proposalId,"SHORTLISTED")?.onSuccess{items=items.map{if(it.proposalId==p.proposalId)it.copy(status=ProposalStatus.SHORTLISTED)else it}}?.onFailure{error=it.message}}}){Text("Shortlist")};OutlinedButton(enabled=p.proposalId.isNotBlank()&&p.status!=ProposalStatus.REJECTED,onClick={scope.launch{marketplace?.updateStatusByProposalId(p.proposalId,"REJECTED")?.onSuccess{items=items.map{if(it.proposalId==p.proposalId)it.copy(status=ProposalStatus.REJECTED)else it}}?.onFailure{error=it.message}}}){Text("Reject")}}}}}}
    }
}
}

@Composable fun CoursesScreen(){LazyColumn(Modifier.padding(16.dp)){item{Text("Courses",style=MaterialTheme.typography.headlineSmall)};items(courses){(title,price)->ElevatedCard(Modifier.fillMaxWidth().padding(vertical=6.dp)){Column(Modifier.padding(16.dp)){Text(title,style=MaterialTheme.typography.titleMedium);Text(price);Button(onClick={}){Text(if(price=="Free")"Start learning" else "View course")}}}}}}
@Composable fun MessagesScreen(marketplace:RemoteMarketplaceRepository?,userId:String,open:(Conversation)->Unit){
    var items by remember{mutableStateOf<List<Conversation>>(emptyList())}; var loading by remember{mutableStateOf(true)}; var error by remember{mutableStateOf<String?>(null)}
    val scope=rememberCoroutineScope()
    LaunchedEffect(marketplace){ if(marketplace!=null){loading=true; marketplace.conversations().onSuccess{items=it}.onFailure{error=it.message}; loading=false}else loading=false }
    Column(Modifier.fillMaxSize().padding(16.dp)){ Text("Messages",style=MaterialTheme.typography.headlineSmall); Spacer(Modifier.height(8.dp));
        if(loading) LinearProgressIndicator(Modifier.fillMaxWidth()); error?.let{Text(it,color=MaterialTheme.colorScheme.error)}
        if(!loading && items.isEmpty()) Text("No conversations yet. Start a conversation from a job.",modifier=Modifier.padding(top=16.dp))
        LazyColumn{items(items){c->ElevatedCard(onClick={open(c)},modifier=Modifier.fillMaxWidth().padding(vertical=5.dp)){Column(Modifier.padding(16.dp)){Text(if(c.freelancerId==userId)"Client" else "Freelancer",style=MaterialTheme.typography.titleMedium);Text(if(c.lastMessage.isBlank())"No messages yet" else c.lastMessage)}}}}
    }
}

@Composable fun ChatScreen(marketplace:RemoteMarketplaceRepository?,conversation:Conversation,userId:String,back:()->Unit){
    var messages by remember{mutableStateOf<List<ChatMessage>>(emptyList())}; var text by remember{mutableStateOf("")}; var error by remember{mutableStateOf<String?>(null)}; var sending by remember{mutableStateOf(false)}
    val scope=rememberCoroutineScope()
    LaunchedEffect(conversation.id){if(marketplace!=null) marketplace.messages(conversation.id).onSuccess{messages=it}.onFailure{error=it.message}}
    Column(Modifier.fillMaxSize()){ Row(Modifier.fillMaxWidth().padding(8.dp),verticalAlignment=Alignment.CenterVertically){IconButton(onClick=back){Icon(Icons.Default.ArrowBack,"Back")};Text("Conversation",style=MaterialTheme.typography.titleLarge)}
        error?.let{Text(it,color=MaterialTheme.colorScheme.error,modifier=Modifier.padding(horizontal=16.dp))}
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal=12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){items(messages){m->Row(Modifier.fillMaxWidth(),horizontalArrangement=if(m.senderId==userId)Arrangement.End else Arrangement.Start){Surface(shape=MaterialTheme.shapes.medium,tonalElevation=2.dp){Text(m.body,Modifier.padding(12.dp))}}}}
        Row(Modifier.fillMaxWidth().padding(10.dp),verticalAlignment=Alignment.CenterVertically){OutlinedTextField(text,{text=it},label={Text("Message")},modifier=Modifier.weight(1f));Spacer(Modifier.width(8.dp));Button(enabled=!sending&&text.isNotBlank()&&marketplace!=null,onClick={scope.launch{sending=true;marketplace?.sendMessage(conversation.id,text).onSuccess{messages=messages+it;text=""}.onFailure{error=it.message};sending=false}}){Text("Send")}}
    }
}

@Composable fun NotificationsScreen(marketplace:RemoteMarketplaceRepository?,back:()->Unit,onReadAll:()->Unit){
    var items by remember{mutableStateOf<List<AppNotification>>(emptyList())}; var error by remember{mutableStateOf<String?>(null)}; val scope=rememberCoroutineScope()
    LaunchedEffect(marketplace){if(marketplace!=null)marketplace.notifications().onSuccess{items=it}.onFailure{error=it.message}}
    Column(Modifier.fillMaxSize()){Row(Modifier.fillMaxWidth().padding(8.dp),verticalAlignment=Alignment.CenterVertically){IconButton(onClick=back){Icon(Icons.Default.ArrowBack,"Back")};Text("Notifications",style=MaterialTheme.typography.titleLarge)};error?.let{Text(it,color=MaterialTheme.colorScheme.error,modifier=Modifier.padding(16.dp))}
        LazyColumn(Modifier.fillMaxWidth().padding(12.dp)){items(items){n->ElevatedCard(onClick={if(!n.read&&marketplace!=null)scope.launch{marketplace.markNotificationRead(n.id).onSuccess{items=items.map{if(it.id==n.id)it.copy(read=true)else it}; onReadAll()}}},modifier=Modifier.fillMaxWidth().padding(vertical=4.dp)){Column(Modifier.padding(16.dp)){Text(n.title,style=MaterialTheme.typography.titleMedium);Text(n.body);if(!n.read)Text("Unread",style=MaterialTheme.typography.labelMedium)}}}}
    }
}


@Composable fun ProfileScreen(repo:AppRepository,edit:()->Unit,logout:()->Unit){
    val p=repo.profile()
    LazyColumn(Modifier.fillMaxSize().padding(20.dp)){
        item{Text("Profile",style=MaterialTheme.typography.headlineSmall);Spacer(Modifier.height(12.dp));Text(if(p.name.isBlank())"Your profile is not completed yet." else p.name,style=MaterialTheme.typography.titleLarge);Text(p.email);Spacer(Modifier.height(8.dp));Text(p.bio);Spacer(Modifier.height(8.dp));Text(if(p.skills.isBlank())"Add your skills" else "Skills: ${p.skills}");Spacer(Modifier.height(16.dp));Text("Portfolio",style=MaterialTheme.typography.titleLarge);Spacer(Modifier.height(8.dp))}
        if(p.portfolio.isEmpty()) item{Text("Showcase your best work by adding portfolio projects.",style=MaterialTheme.typography.bodyMedium)}
        items(p.portfolio){item->ElevatedCard(Modifier.fillMaxWidth().padding(vertical=5.dp)){Column(Modifier.padding(14.dp)){Text(item.title,style=MaterialTheme.typography.titleMedium);if(item.description.isNotBlank())Text(item.description);if(item.skills.isNotBlank())Text("Skills: ${item.skills}");if(item.url.isNotBlank())Text(item.url,style=MaterialTheme.typography.bodySmall)}}}
        item{Spacer(Modifier.height(16.dp));Button(onClick=edit,modifier=Modifier.fillMaxWidth()){Text("Edit profile & portfolio")};OutlinedButton(onClick=logout,modifier=Modifier.fillMaxWidth()){Text("Sign out")}}
    }
}
@Composable fun ProfileEditor(repo:AppRepository, marketplace:RemoteMarketplaceRepository?, done:()->Unit){
    val old=repo.profile(); var name by remember{mutableStateOf(old.name)}; var email by remember{mutableStateOf(old.email)}; var bio by remember{mutableStateOf(old.bio)}; var skills by remember{mutableStateOf(old.skills)}; var role by remember{mutableStateOf(old.role)}; var portfolio by remember{mutableStateOf(old.portfolio)}; var error by remember{mutableStateOf<String?>(null)}; var saving by remember{mutableStateOf(false)}; var pTitle by remember{mutableStateOf("")}; var pDesc by remember{mutableStateOf("")}; var pUrl by remember{mutableStateOf("")}; var pSkills by remember{mutableStateOf("")}; val scope=rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(20.dp)){
        Text("Edit profile",style=MaterialTheme.typography.headlineSmall);Spacer(Modifier.height(12.dp));
        OutlinedTextField(name,{name=it},label={Text("Name")},modifier=Modifier.fillMaxWidth());OutlinedTextField(email,{email=it},label={Text("Email")},enabled=false,modifier=Modifier.fillMaxWidth());OutlinedTextField(bio,{bio=it},label={Text("Bio")},modifier=Modifier.fillMaxWidth());OutlinedTextField(skills,{skills=it},label={Text("Skills (comma separated)")},modifier=Modifier.fillMaxWidth());
        Spacer(Modifier.height(12.dp));Text("Account type",style=MaterialTheme.typography.titleMedium);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={role=UserRole.FREELANCER},enabled=role!=UserRole.FREELANCER){Text("Freelancer")};Button(onClick={role=UserRole.CLIENT},enabled=role!=UserRole.CLIENT){Text("Client")}}
        Spacer(Modifier.height(18.dp));Text("Add portfolio project",style=MaterialTheme.typography.titleLarge);Spacer(Modifier.height(8.dp));
        OutlinedTextField(pTitle,{pTitle=it},label={Text("Project title")},modifier=Modifier.fillMaxWidth());OutlinedTextField(pDesc,{pDesc=it},label={Text("Description")},modifier=Modifier.fillMaxWidth());OutlinedTextField(pUrl,{pUrl=it},label={Text("Project URL (optional)")},modifier=Modifier.fillMaxWidth());OutlinedTextField(pSkills,{pSkills=it},label={Text("Project skills")},modifier=Modifier.fillMaxWidth());
        Button(enabled=pTitle.trim().length>=2&&portfolio.size<20,onClick={portfolio=portfolio+PortfolioItem(pTitle.trim(),pDesc.trim(),pUrl.trim(),pSkills.trim());pTitle="";pDesc="";pUrl="";pSkills=""},modifier=Modifier.fillMaxWidth()){Text("Add project")};
        if(portfolio.isNotEmpty()){Spacer(Modifier.height(8.dp));portfolio.forEachIndexed{index,item->ElevatedCard(Modifier.fillMaxWidth().padding(vertical=4.dp)){Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(item.title,style=MaterialTheme.typography.titleMedium);if(item.description.isNotBlank())Text(item.description);if(item.url.isNotBlank())Text(item.url,style=MaterialTheme.typography.bodySmall)};TextButton(onClick={portfolio=portfolio.filterIndexed{i,_->i!=index}}){Text("Remove")}}}}}
        error?.let{Text(it,color=MaterialTheme.colorScheme.error)};Spacer(Modifier.height(12.dp));Button(enabled=!saving&&Validation.text(name,2,80)&&Validation.text(bio,0,500)&&Validation.text(skills,0,500),onClick={val next=UserProfile(name.trim(),old.email,bio.trim(),skills.trim(),role,portfolio);scope.launch{saving=true;error=null;if(marketplace!=null)marketplace.updateProfile(next).onSuccess{repo.saveProfile(it);done()}.onFailure{error=it.message ?: "Unable to save profile"}else{repo.saveProfile(next);done()};saving=false}},modifier=Modifier.fillMaxWidth()){Text(if(saving)"Saving…" else "Save profile")}
    }
}
