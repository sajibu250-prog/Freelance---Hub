package com.freelancehub.app.data

/** Provider-neutral contract; the Android client must never contain admin/service secrets. */
object ApiContract {
    const val API_VERSION = "v1"
    const val LOGIN = "/$API_VERSION/auth/login"
    const val SIGNUP = "/$API_VERSION/auth/signup"
    const val REFRESH = "/$API_VERSION/auth/refresh"
    const val LOGOUT = "/$API_VERSION/auth/logout"
    const val JOBS = "/$API_VERSION/jobs"
    const val JOB_BY_ID = "/$API_VERSION/jobs/{jobId}"
    const val JOB_STATUS = "/$API_VERSION/jobs/{jobId}"
    const val PROPOSALS = "/$API_VERSION/jobs/{jobId}/proposals"
    const val PROPOSAL_STATUS = "/$API_VERSION/proposals/{proposalId}"
    const val MESSAGES = "/$API_VERSION/messages"
    const val PROFILE = "/$API_VERSION/me"
    const val MY_PROPOSALS = "/$API_VERSION/me/proposals"
    const val MY_JOBS = "/$API_VERSION/me/jobs"
    const val RELEASES = "/$API_VERSION/app/releases/android"
    const val NOTIFICATIONS = "/$API_VERSION/notifications"
    const val CONVERSATIONS = "/$API_VERSION/messages/conversations"
    const val PAYMENT_INTENTS = "/$API_VERSION/payments/intents"
    const val ESCROW_RELEASE = "/$API_VERSION/payments/escrow/release"
    const val REFUNDS = "/$API_VERSION/payments/refunds"
    const val DISPUTES = "/$API_VERSION/disputes"

    fun proposalsForJob(jobId: String) = PROPOSALS.replace("{jobId}", jobId)
    fun proposal(proposalId: String) = PROPOSAL_STATUS.replace("{proposalId}", proposalId)
    fun jobStatus(jobId: String) = JOB_STATUS.replace("{jobId}", jobId)
    fun messages(conversationId: String) = "$MESSAGES/$conversationId"
    fun notificationRead(notificationId: String) = "$NOTIFICATIONS/$notificationId/read"
}

data class AuthRequest(val email:String,val password:String,val role:String="FREELANCER",val name:String?=null)
data class AuthResponse(val accessToken:String,val userId:String,val role:String, val expiresAtEpochSeconds:Long?=null, val refreshToken:String?=null)
