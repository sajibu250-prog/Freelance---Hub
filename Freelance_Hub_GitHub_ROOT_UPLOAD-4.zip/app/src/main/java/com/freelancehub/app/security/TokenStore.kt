package com.freelancehub.app.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Device-local access-token storage using Android Keystore AES/GCM.
 * Production auth should still use short-lived access tokens and refresh-token rotation.
 */
class TokenStore(context: Context) {
    private val prefs = context.getSharedPreferences("secure_session", Context.MODE_PRIVATE)
    private val keyAlias = "freelance_hub_session_key"
    private val transformation = "AES/GCM/NoPadding"

    fun saveAccessToken(token: String, expiresAtEpochSeconds: Long? = null) {
        require(token.isNotBlank())
        val cipher = Cipher.getInstance(transformation)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(token.toByteArray(StandardCharsets.UTF_8))
        prefs.edit()
            .putString("token", Base64.encodeToString(encrypted, Base64.NO_WRAP))
            .putString("iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .apply { if (expiresAtEpochSeconds != null) putLong("expires_at", expiresAtEpochSeconds) }
            .apply()
    }


    fun accessTokenExpiresAt(): Long? = prefs.getLong("expires_at", 0L).takeIf { it > 0L }

    fun isAccessTokenFresh(leewaySeconds: Long = 60L): Boolean = accessTokenExpiresAt()?.let { it > (System.currentTimeMillis()/1000L + leewaySeconds) } ?: false

    fun saveRefreshToken(token: String) {
        require(token.isNotBlank())
        val cipher = Cipher.getInstance(transformation)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(token.toByteArray(StandardCharsets.UTF_8))
        prefs.edit().putString("refresh_token", Base64.encodeToString(encrypted, Base64.NO_WRAP)).putString("refresh_iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP)).apply()
    }

    fun readRefreshToken(): String? = runCatching {
        val encoded = prefs.getString("refresh_token", null) ?: return null
        val ivEncoded = prefs.getString("refresh_iv", null) ?: return null
        val cipher = Cipher.getInstance(transformation)
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, Base64.decode(ivEncoded, Base64.NO_WRAP)))
        String(cipher.doFinal(Base64.decode(encoded, Base64.NO_WRAP)), StandardCharsets.UTF_8)
    }.getOrNull()

    fun readAccessToken(): String? = runCatching {
        val encoded = prefs.getString("token", null) ?: return null
        val ivEncoded = prefs.getString("iv", null) ?: return null
        val cipher = Cipher.getInstance(transformation)
        cipher.init(
            Cipher.DECRYPT_MODE,
            getOrCreateKey(),
            GCMParameterSpec(128, Base64.decode(ivEncoded, Base64.NO_WRAP))
        )
        String(cipher.doFinal(Base64.decode(encoded, Base64.NO_WRAP)), StandardCharsets.UTF_8)
    }.getOrNull()

    fun clear() {
        prefs.edit().clear().apply()
    }

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (keyStore.getKey(keyAlias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                keyAlias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }
}
