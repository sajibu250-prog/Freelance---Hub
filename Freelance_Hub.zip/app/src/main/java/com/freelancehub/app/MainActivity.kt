package com.freelancehub.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.freelancehub.app.data.*
import com.freelancehub.app.update.PlayUpdateManager

private val jobs=listOf(
    Job(1,"Build a modern business website","Acme Studio","$300–$600","WordPress, UI/UX","Responsive website for a growing business."),
    Job(2,"Social media content designer","Nova Brand","$100–$250","Canva, Photoshop","Create a monthly pack of social media creatives."),
    Job(3,"Android app UI implementation","TechWorks","$500–$900","Kotlin, Compose","Implement polished Android screens from a design system."),
    Job(4,"SEO content writer","Global Media","$150–$400","SEO, Writing","Write optimized English articles for international readers.")
)
private val courses=listOf("Freelancing Fundamentals" to "Free","Digital Marketing Masterclass" to "$29","AI Tools for Freelancers" to "$19")
class MainActivity:ComponentActivity(){
    private lateinit var playUpdateManager: PlayUpdateManager
    override fun onCreate(b:Bundle?){
        super.onCreate(b)
        playUpdateManager = PlayUpdateManager(this)
        setContent{FreelanceHubApp(AppRepository(this))}
    }
    override fun onResume(){
        super.onResume()
        if (::playUpdateManager.isInitialized) playUpdateManager.resumeIfInterrupted()
    }
    override fun onStart(){
        super.onStart()
        if (::playUpdateManager.isInitialized) playUpdateManager.checkForUpdate()
    }
}
@Composable fun FreelanceHubApp(repo:AppRepository){var loggedIn by remember{mutableStateOf(repo.isLoggedIn())};if(!loggedIn)LoginScreen{repo.setLoggedIn(true);loggedIn=true}else MainShell(repo){repo.setLoggedIn(false);loggedIn=false}}
@Composable fun LoginScreen(onLogin:()->Unit){var signup by remember{mutableStateOf(false)};var email by remember{mutableStateOf("")};var pass by remember{mutableStateOf("")};Column(Modifier.fillMaxSize().padding(28.dp),verticalArrangement=Arrangement.Center){Text("Freelance Hub",style=MaterialTheme.typography.headlineLarge);Text("Global freelance marketplace",style=MaterialTheme.typography.bodyLarge);Spacer(Modifier.height(24.dp));if(signup){var name by remember{mutableStateOf("")};OutlinedTextField(name,{name=it},label={Text("Full name")},modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(10.dp))};OutlinedTextField(email,{email=it},label={Text("Email")},modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(10.dp));OutlinedTextField(pass,{pass=it},label={Text("Password")},visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(18.dp));Button(onClick=onLogin,enabled=Validation.email(email)&&Validation.password(pass),modifier=Modifier.fillMaxWidth()){Text(if(signup)"Create account" else "Continue")};TextButton(onClick={signup=!signup}){Text(if(signup)"Already have an account? Sign in" else "Create a new account")}}}
@Composable fun MainShell(repo:AppRepository,logout:()->Unit){
    var tab by remember{mutableStateOf(0)}
    var selected by remember{mutableStateOf<Job?>(null)}
    var proposal by remember{mutableStateOf<Job?>(null)}
    var editing by remember{mutableStateOf(false)}
    var role by remember{mutableStateOf(repo.profile().role)}
    var showPostJob by remember{mutableStateOf(false)}
    var count by remember{mutableStateOf(repo.proposals().size)}
    Scaffold(bottomBar={NavigationBar{listOf("Home","Jobs","Courses","Messages","Profile").forEachIndexed{i,n->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Icon(listOf(Icons.Default.Home,Icons.Default.Work,Icons.Default.School,Icons.Default.Chat,Icons.Default.Person)[i],n)},label={Text(n)})}}}){p->
        Box(Modifier.padding(p)){when{
            proposal!=null->ProposalScreen(proposal!!,{proposal=null}){repo.addProposal(it);count++;proposal=null}
            selected!=null->JobDetails(selected!!,{selected=null}){proposal=selected}
            showPostJob->PostJobScreen({showPostJob=false}){repo.saveJob(it);showPostJob=false}
            editing->ProfileEditor(repo){role=repo.profile().role;editing=false}
            tab==0->HomeScreen(role){if(role==UserRole.CLIENT)showPostJob=true}
            tab==1->JobsScreen(repo,role,{selected=it}){showPostJob=true}
            tab==2->CoursesScreen()
            tab==3->MessagesScreen(count)
            else->ProfileScreen(repo,{editing=true},{logout()})
        }}
    }
}

@Composable fun HomeScreen(role:UserRole,onPostJob:()->Unit){LazyColumn(Modifier.fillMaxSize().padding(20.dp)){item{Text("Welcome to Freelance Hub",style=MaterialTheme.typography.headlineMedium);Text("Work globally. Learn skills. Build your career.");Spacer(Modifier.height(20.dp));Text("Quick actions",style=MaterialTheme.typography.titleLarge); if(role==UserRole.CLIENT){Spacer(Modifier.height(10.dp));Button(onClick=onPostJob,modifier=Modifier.fillMaxWidth()){Text("Post a job")}}};items(listOf("Find freelance jobs","Learn practical skills","Build your portfolio","Explore Premium")){ElevatedCard(Modifier.fillMaxWidth().padding(vertical=5.dp)){Text(it,Modifier.padding(18.dp))}}}}
@Composable fun JobsScreen(repo:AppRepository,role:UserRole,open:(Job)->Unit,post:()->Unit){
    var query by remember{mutableStateOf("")}
    val all=(jobs+repo.savedJobs()).distinctBy{it.id}
    val filtered=all.filter{it.title.contains(query,true)||it.skills.contains(query,true)||it.client.contains(query,true)}
    Column(Modifier.fillMaxSize().padding(16.dp)){
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Jobs",style=MaterialTheme.typography.headlineSmall);if(role==UserRole.CLIENT)Button(onClick=post){Text("Post job")}}
        Spacer(Modifier.height(8.dp));OutlinedTextField(query,{query=it},label={Text("Search jobs, skills or clients")},modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(8.dp));
        LazyColumn{items(filtered){j->ElevatedCard(onClick={open(j)},modifier=Modifier.fillMaxWidth().padding(vertical=6.dp)){Column(Modifier.padding(16.dp)){Text(j.title,style=MaterialTheme.typography.titleMedium);Text(j.client);Text("Budget: ${j.budget}");Text(j.skills);Text(if(j.remote)"Remote • Global" else "On-site")}}}}}
}

@Composable fun PostJobScreen(back:()->Unit,onSave:(Job)->Unit){
    var title by remember{mutableStateOf("")};var client by remember{mutableStateOf("")};var budget by remember{mutableStateOf("")};var skills by remember{mutableStateOf("")};var desc by remember{mutableStateOf("")};var error by remember{mutableStateOf(false)}
    Column(Modifier.fillMaxSize().padding(20.dp)){Text("Post a job",style=MaterialTheme.typography.headlineSmall);Spacer(Modifier.height(12.dp));
    OutlinedTextField(title,{title=it},label={Text("Job title")},modifier=Modifier.fillMaxWidth());OutlinedTextField(client,{client=it},label={Text("Client / company")},modifier=Modifier.fillMaxWidth());OutlinedTextField(budget,{budget=it},label={Text("Budget (USD)")},modifier=Modifier.fillMaxWidth());OutlinedTextField(skills,{skills=it},label={Text("Skills")},modifier=Modifier.fillMaxWidth());
        OutlinedTextField(desc,{desc=it},label={Text("Description")},minLines=4,modifier=Modifier.fillMaxWidth());if(error)Text("Complete all fields.",color=MaterialTheme.colorScheme.error);Spacer(Modifier.height(12.dp));Button(onClick={if(listOf(title,client,budget,skills,desc).all{it.isNotBlank()})onSave(Job((System.currentTimeMillis()%1000000).toInt(),title,client,budget,skills,desc))else error=true},modifier=Modifier.fillMaxWidth()){Text("Publish job")};TextButton(onClick=back){Text("Cancel")}}
}

@Composable fun JobDetails(j:Job,back:()->Unit,apply:()->Unit){Column(Modifier.fillMaxSize().padding(20.dp)){Text(j.title,style=MaterialTheme.typography.headlineSmall);Text("Client: ${j.client}");Text("Budget: ${j.budget}");Text("Skills: ${j.skills}");Text(j.description);Text(if(j.remote)"Remote • Global" else "On-site");Spacer(Modifier.height(20.dp));Button(onClick=apply,modifier=Modifier.fillMaxWidth()){Text("Submit proposal")};TextButton(onClick=back){Text("Back")}}}
@Composable fun ProposalScreen(j:Job,back:()->Unit,onSubmit:(Proposal)->Unit){var letter by remember{mutableStateOf("")};var bid by remember{mutableStateOf("")};var delivery by remember{mutableStateOf("")};var error by remember{mutableStateOf(false)};Column(Modifier.fillMaxSize().padding(20.dp)){Text("Proposal",style=MaterialTheme.typography.headlineSmall);Text(j.title);Spacer(Modifier.height(12.dp));OutlinedTextField(letter,{letter=it},label={Text("Cover letter")},minLines=5,modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(8.dp));OutlinedTextField(bid,{bid=it},label={Text("Your bid (USD)")},modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(8.dp));OutlinedTextField(delivery,{delivery=it},label={Text("Delivery time")},modifier=Modifier.fillMaxWidth());if(error)Text("Complete all fields.",color=MaterialTheme.colorScheme.error);Spacer(Modifier.height(12.dp));Button(onClick={if(letter.isNotBlank()&&bid.isNotBlank()&&delivery.isNotBlank())onSubmit(Proposal(j.id,letter,bid,delivery))else error=true},modifier=Modifier.fillMaxWidth()){Text("Send proposal")};TextButton(onClick=back){Text("Cancel")}}}
@Composable fun CoursesScreen(){LazyColumn(Modifier.padding(16.dp)){item{Text("Courses",style=MaterialTheme.typography.headlineSmall)};items(courses){(title,price)->ElevatedCard(Modifier.fillMaxWidth().padding(vertical=6.dp)){Column(Modifier.padding(16.dp)){Text(title,style=MaterialTheme.typography.titleMedium);Text(price);Button(onClick={}){Text(if(price=="Free")"Start learning" else "View course")}}}}}}
@Composable fun MessagesScreen(n:Int){Column(Modifier.fillMaxSize().padding(20.dp)){Text("Messages",style=MaterialTheme.typography.headlineSmall);Spacer(Modifier.height(12.dp));Text(if(n==0)"No conversations yet." else "${n} proposal(s) submitted. Client messaging will activate after backend integration.")}}
@Composable fun ProfileScreen(repo:AppRepository,edit:()->Unit,logout:()->Unit){val p=repo.profile();Column(Modifier.fillMaxSize().padding(20.dp)){Text("Profile",style=MaterialTheme.typography.headlineSmall);Spacer(Modifier.height(12.dp));Text(if(p.name.isBlank())"Your profile is not completed yet." else p.name);Text(p.email);Text(p.bio);Text(if(p.skills.isBlank())"Add your skills" else p.skills);Spacer(Modifier.height(20.dp));Button(onClick=edit){Text("Edit profile")};OutlinedButton(onClick=logout){Text("Sign out")}}}
@Composable fun ProfileEditor(repo:AppRepository,done:()->Unit){val old=repo.profile();var name by remember{mutableStateOf(old.name)};var email by remember{mutableStateOf(old.email)};var bio by remember{mutableStateOf(old.bio)};var skills by remember{mutableStateOf(old.skills)};var role by remember{mutableStateOf(old.role)};Column(Modifier.fillMaxSize().padding(20.dp)){Text("Edit profile",style=MaterialTheme.typography.headlineSmall);Spacer(Modifier.height(12.dp));OutlinedTextField(name,{name=it},label={Text("Name")},modifier=Modifier.fillMaxWidth());OutlinedTextField(email,{email=it},label={Text("Email")},modifier=Modifier.fillMaxWidth());OutlinedTextField(bio,{bio=it},label={Text("Bio")},modifier=Modifier.fillMaxWidth());OutlinedTextField(skills,{skills=it},label={Text("Skills")},modifier=Modifier.fillMaxWidth());
        Spacer(Modifier.height(12.dp));Text("Account type",style=MaterialTheme.typography.titleMedium);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={role=UserRole.FREELANCER},enabled=role!=UserRole.FREELANCER){Text("Freelancer")};Button(onClick={role=UserRole.CLIENT},enabled=role!=UserRole.CLIENT){Text("Client")}};Spacer(Modifier.height(12.dp));Button(onClick={repo.saveProfile(UserProfile(name,email,bio,skills,role));done()},enabled=Validation.text(name,2,80)&&Validation.email(email)&&Validation.text(bio,0,500)&&Validation.text(skills,0,500),modifier=Modifier.fillMaxWidth()){Text("Save profile")}}}
