# Freelance Hub — v1.17

Global-first Android foundation for the Freelance Hub personal-brand product. This project is independent of any other institute or organization.

## What was advanced in v1.17
- Added Google Play official in-app update integration.
- Handles an interrupted immediate update when the app resumes.
- Does **not** silently install arbitrary APKs.
- Keeps server/data updates separate from app-binary updates.
- Preserves the existing API contract, PostgreSQL schema/RLS foundation, job/proposal/profile flows and security gates.

## Important release condition
The Play update flow becomes active only after the Android app is published to Google Play and a newer version is available through the Play release track. A production backend, Play signing, privacy/account controls and testing are still required.

## Build verification
This environment contains Java 21 but does not contain a Gradle executable or Gradle wrapper in the project, so a real APK build was **not** claimed or reported as verified here. Before release, add/pin the Gradle wrapper and Android SDK, then run the project's build and tests in a properly provisioned Android build environment.

## Production checklist
See `RELEASE_READINESS.md`, `SECURITY_RELEASE_GATES.md`, `SECURITY_CHECKLIST.md` and `PRODUCTION_TEST_MATRIX.md`.
