# Freelance Hub security checklist

## Client application
- Never embed service-account, admin, payment, or signing secrets.
- Use HTTPS only for production API endpoints.
- Treat all client-supplied role/status/price fields as untrusted.
- Store access credentials only in platform-protected storage after backend integration.
- Do not log passwords, access tokens, payment details, or private messages.

## Server requirements before launch
- Short-lived access tokens + refresh-token rotation/revocation.
- Server-side authorization on every job, proposal, message, course, and admin operation.
- Ownership checks for every read/write operation.
- Rate limiting, abuse prevention, input-size limits, and validation.
- Payment verification through signed server-side webhooks; never unlock Premium from a client callback alone.
- Audit logs for admin and financial actions.
- Account deletion and data export flows.
- Privacy policy, terms, reporting/moderation, and support contact.

## Release gate
A release should not be considered production-ready until automated tests, backend security rules, crash monitoring, signed AAB generation, and a clean-device smoke test pass.
