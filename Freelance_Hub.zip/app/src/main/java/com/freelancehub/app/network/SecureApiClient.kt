package com.freelancehub.app.network

import com.freelancehub.app.data.BackendConfig
import com.freelancehub.app.data.SecurityHeaders
import java.net.HttpURLConnection
import java.net.URI
import java.util.UUID

/**
 * Small provider-neutral HTTPS transport foundation.
 * Authentication/business mapping stays outside this class so secrets are never embedded in the APK.
 */
class SecureApiClient(private val config: BackendConfig) {
    init {
        require(URI(config.baseUrl).scheme.equals("https", true)) {
            "Production API must use HTTPS"
        }
    }

    fun openGet(path: String, accessToken: String? = null): HttpURLConnection {
        return open("GET", path, accessToken, null)
    }

    fun openJsonPost(
        path: String,
        body: ByteArray,
        accessToken: String? = null,
        idempotencyKey: String? = null
    ): HttpURLConnection {
        return open("POST", path, accessToken, body).also { connection ->
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            idempotencyKey?.let { connection.setRequestProperty(SecurityHeaders.IDEMPOTENCY_KEY, it) }
            connection.doOutput = true
            connection.outputStream.use { it.write(body) }
        }
    }

    private fun open(method: String, path: String, accessToken: String?, body: ByteArray?): HttpURLConnection {
        require(path.startsWith("/")) { "API path must start with /" }
        val url = URI(config.baseUrl.trimEnd('/') + path).toURL()
        val connection = url.openConnection() as HttpURLConnection
        connection.requestMethod = method
        connection.connectTimeout = 10_000
        connection.readTimeout = 20_000
        connection.useCaches = false
        connection.setRequestProperty("Accept", "application/json")
        connection.setRequestProperty(SecurityHeaders.REQUEST_ID, UUID.randomUUID().toString())
        accessToken?.takeIf { it.isNotBlank() }?.let {
            connection.setRequestProperty("Authorization", "Bearer $it")
        }
        return connection
    }

    companion object {
        fun newIdempotencyKey(): String = UUID.randomUUID().toString()
    }
}
