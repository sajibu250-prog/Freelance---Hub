# Production test matrix

## Authentication
- Invalid email/password rejected without revealing which field matched.
- Access token expiry handled with refresh-token rotation.
- Logout revokes/invalidates refresh token.
- Replayed refresh tokens are rejected.

## Authorization
- Freelancer cannot create jobs.
- Client cannot submit proposals.
- A user cannot edit another user's profile, job, or proposal.
- Proposal visibility is limited to the freelancer and job owner.

## Data integrity
- Duplicate `(job_id, freelancer_id)` proposal is rejected.
- Money is stored as integer minor units plus ISO-4217 currency code.
- Invalid status transitions are rejected server-side.

## Abuse/security
- Rate-limit login, signup, proposal creation, messaging, and password reset.
- Validate upload MIME type/size and store uploads outside the database.
- Redact access tokens, passwords, payment secrets, and PII from logs.
- Verify payment webhooks cryptographically before granting Premium.

## Release
- Run unit, integration, UI, and migration tests in CI.
- Build signed AAB from a clean checkout.
- Verify release build contains no debug logging or secrets.
