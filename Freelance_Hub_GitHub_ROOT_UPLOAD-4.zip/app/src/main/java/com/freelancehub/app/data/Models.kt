package com.freelancehub.app.data

enum class UserRole { FREELANCER, CLIENT }

object JobStatus { const val OPEN = "Open"; const val PAUSED = "Paused"; const val CLOSED = "Closed" }
object ProposalStatus { const val SUBMITTED = "Submitted"; const val SHORTLISTED = "Shortlisted"; const val ACCEPTED = "Accepted"; const val REJECTED = "Rejected" }

data class Job(
    val id:String,
    val title:String,
    val client:String,
    val budget:String,
    val skills:String,
    val description:String="",
    val remote:Boolean=true,
    val status:String=JobStatus.OPEN,
    val createdAt:Long=System.currentTimeMillis(),
    val clientId:String="",
    val proposalCount:Int=0
)

data class Proposal(
    val jobId:String,
    val coverLetter:String,
    val bid:String,
    val delivery:String,
    val status:String=ProposalStatus.SUBMITTED,
    val createdAt:Long=System.currentTimeMillis(),
    val proposalId:String="",
    val freelancerId:String="",
    val jobTitle:String=""
)

data class PortfolioItem(
    val title:String="",
    val description:String="",
    val url:String="",
    val skills:String=""
)

data class UserProfile(
    val name:String="",
    val email:String="",
    val bio:String="",
    val skills:String="",
    val role:UserRole=UserRole.FREELANCER,
    val portfolio:List<PortfolioItem> = emptyList()
)


data class Conversation(
    val id:String, val freelancerId:String, val clientId:String,
    val lastMessage:String="", val lastMessageAt:String=""
)
data class ChatMessage(val id:String, val senderId:String, val body:String, val createdAt:String="")
data class AppNotification(
    val id:String, val type:String, val title:String, val body:String,
    val read:Boolean=false, val createdAt:String=""
)
