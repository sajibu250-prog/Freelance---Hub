-- Provider-neutral relational baseline for the production backend.
-- Apply server-side authorization/RLS policies before exposing these tables.
CREATE TABLE users (
  id UUID PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  display_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('FREELANCER','CLIENT')),
  bio TEXT NOT NULL DEFAULT '',
  skills JSONB NOT NULL DEFAULT '[]',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE jobs (
  id UUID PRIMARY KEY,
  client_id UUID NOT NULL REFERENCES users(id),
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  budget_minor BIGINT NOT NULL CHECK (budget_minor >= 0),
  currency CHAR(3) NOT NULL,
  skills JSONB NOT NULL DEFAULT '[]',
  status TEXT NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN','PAUSED','CLOSED')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE proposals (
  id UUID PRIMARY KEY,
  job_id UUID NOT NULL REFERENCES jobs(id),
  freelancer_id UUID NOT NULL REFERENCES users(id),
  cover_letter TEXT NOT NULL,
  bid_minor BIGINT NOT NULL CHECK (bid_minor >= 0),
  currency CHAR(3) NOT NULL,
  delivery_days INT NOT NULL CHECK (delivery_days > 0),
  status TEXT NOT NULL DEFAULT 'SUBMITTED' CHECK (status IN ('SUBMITTED','SHORTLISTED','ACCEPTED','REJECTED')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(job_id, freelancer_id)
);

CREATE INDEX jobs_client_id_idx ON jobs(client_id);
CREATE INDEX jobs_status_created_idx ON jobs(status, created_at DESC);
CREATE INDEX proposals_job_id_idx ON proposals(job_id);
CREATE INDEX proposals_freelancer_id_idx ON proposals(freelancer_id);
