# Backend local foundation

This folder provides a reproducible PostgreSQL development environment. It is intentionally separate from the Android client.

## Safety
- Never commit real passwords, JWT signing keys, payment secrets, or provider service keys.
- Use a secrets manager in production.
- Apply schema and RLS together before exposing the database through an API.
- The Android app must never connect directly to PostgreSQL.

## Local start
1. Copy `.env.example` to `.env` and replace the placeholder password.
2. Run `docker compose up -d` from this directory.
3. Connect only through the future API service; the database is exposed locally for development only.
