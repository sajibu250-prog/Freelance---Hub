# Freelance Hub v1.19 — Session Security Foundation

- Added Android Keystore-backed AES/GCM `TokenStore` for device-local access-token protection.
- Added backup exclusion for secure session preferences.
- Added an explicit authentication/security contract covering password hashing, rate limits, refresh-token rotation, authorization, and secret handling.
- Kept the provider-neutral HTTPS API layer and Play In-App Update architecture from v1.18.
- Version: 0.19.0 / versionCode 19.

## Verification limitation
This workspace has Java 21 but no Gradle executable or Android SDK. Therefore APK/AAB compilation and emulator tests have not been claimed as verified here.
