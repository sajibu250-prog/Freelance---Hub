package com.freelancehub.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class AppRepository(context: Context) {
    private val prefs = context.getSharedPreferences("freelance_hub", Context.MODE_PRIVATE)

    fun isLoggedIn() = prefs.getBoolean("logged_in", false)
    fun setLoggedIn(value:Boolean) { prefs.edit().putBoolean("logged_in", value).apply() }

    fun profile(): UserProfile = UserProfile(
        prefs.getString("name", "") ?: "",
        prefs.getString("email", "") ?: "",
        prefs.getString("bio", "") ?: "",
        prefs.getString("skills", "") ?: "",
        runCatching { UserRole.valueOf(prefs.getString("role", UserRole.FREELANCER.name) ?: UserRole.FREELANCER.name) }.getOrDefault(UserRole.FREELANCER)
    )

    fun saveProfile(p:UserProfile) = prefs.edit()
        .putString("name",p.name).putString("email",p.email).putString("bio",p.bio)
        .putString("skills",p.skills).putString("role",p.role.name).putString("portfolio",JSONArray(p.portfolio.map { JSONObject().apply { put("title",it.title); put("description",it.description); put("url",it.url); put("skills",it.skills) } }).toString()).apply()

    fun proposals(): List<Proposal> {
        val a=JSONArray(prefs.getString("proposals","[]"))
        return (0 until a.length()).map { o ->
            val x=a.getJSONObject(o)
            Proposal(jobId=x.getString("jobId"),coverLetter=x.getString("coverLetter"),bid=x.getString("bid"),delivery=x.getString("delivery"),status=x.optString("status","Submitted"),createdAt=x.optLong("createdAt",0L),proposalId=x.optString("proposalId",""),freelancerId=x.optString("freelancerId",""))
        }
    }

    fun addProposal(p:Proposal) {
        val all=proposals().filterNot { it.jobId==p.jobId } + p
        val a=JSONArray(); all.forEach { x -> a.put(JSONObject().apply {
            put("jobId",x.jobId);put("coverLetter",x.coverLetter);put("bid",x.bid);put("delivery",x.delivery);put("status",x.status);put("createdAt",x.createdAt);put("proposalId",x.proposalId);put("freelancerId",x.freelancerId)
        })}; prefs.edit().putString("proposals",a.toString()).apply()
    }

    fun updateProposalStatus(jobId:Int,status:String) {
        val a=JSONArray(); proposals().forEach { x -> a.put(JSONObject().apply {
            put("jobId",x.jobId);put("coverLetter",x.coverLetter);put("bid",x.bid);put("delivery",x.delivery);put("status",if(x.jobId==jobId)status else x.status);put("createdAt",x.createdAt);
        })}; prefs.edit().putString("proposals",a.toString()).apply()
    }

    fun savedJobs(): List<Job> {
        val a=JSONArray(prefs.getString("jobs","[]")); return (0 until a.length()).map { i ->
            val x=a.getJSONObject(i); Job(x.getString("id"),x.getString("title"),x.getString("client"),x.getString("budget"),x.getString("skills"),x.optString("description",""),x.optBoolean("remote",true),x.optString("status","Open"),x.optLong("createdAt",0L),x.optString("clientId",""))
        }
    }

    fun saveJob(job:Job) {
        val all=savedJobs().filterNot { it.id==job.id } + job; val a=JSONArray(); all.forEach { x -> a.put(JSONObject().apply {
            put("id",x.id);put("title",x.title);put("client",x.client);put("budget",x.budget);put("skills",x.skills);put("description",x.description);put("remote",x.remote);put("status",x.status);put("createdAt",x.createdAt);
        })}; prefs.edit().putString("jobs",a.toString()).apply()
    }
}
