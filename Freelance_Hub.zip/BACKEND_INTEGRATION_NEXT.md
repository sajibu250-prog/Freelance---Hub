# Backend Integration — Next Implementation Target

The Android app currently has repository contracts and a provider-neutral API contract. The next implementation stage must connect those contracts to a real authenticated service.

Required production sequence:
1. Identity provider and email verification.
2. Access/refresh token issuance and rotation.
3. PostgreSQL migrations and RLS in the hosted environment.
4. `/me`, jobs and proposals endpoints wired to the Android repository.
5. Server-side validation, pagination, rate limiting and audit logging.
6. Messaging service with participant authorization.
7. Payment provider integration using server-side secrets only.
8. Automated integration tests against a staging backend.

No production credentials belong in this repository or APK.
