# Automatic update architecture

Freelance Hub uses two different update mechanisms:

1. **Server/data updates**: jobs, proposals, messages, notifications and configuration are fetched from the API, so these can change without shipping a new APK.
2. **App binary updates**: Android code/UI changes are distributed through Google Play's official in-app update mechanism. The app must never silently download/install an arbitrary APK or bypass Android/Play security.

## Release metadata endpoint

`GET /v1/app/releases/android?channel=production`

Example response:

```json
{
  "versionCode": 16,
  "versionName": "0.16.0",
  "mandatory": false,
  "downloadUrl": "https://play.google.com/store/apps/details?id=com.freelancehub.app"
}
```

The production server should authenticate where appropriate, use HTTPS, validate the response, and keep release metadata under operator control. The client compares the installed version with the server/Play release and starts the official Play in-app update flow when an update is available.

## Important security rule

Do not implement a custom silent APK installer. That would create an unnecessary security risk and can conflict with Android/Google Play distribution rules.
