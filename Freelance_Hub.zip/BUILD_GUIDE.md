# Freelance Hub — Build & Release Guide

## Local Android build

This repository requires:
- JDK 17
- Android SDK with API 35 platform/build tools
- Gradle 8.10.x (or the pinned compatible version used by the Android Gradle Plugin)

The current development environment does not contain an Android SDK or Gradle wrapper, so an APK/AAB has not been claimed as build-verified here.

Recommended first verification in a provisioned environment:

```text
./gradlew --version
./gradlew assembleDebug
./gradlew test
```

For release:

```text
./gradlew bundleRelease
```

Use a protected signing configuration supplied outside source control. Never commit keystores, passwords, API secrets, service-account JSON, or production `.env` files.

## Update behavior

Freelance Hub uses Google Play In-App Updates for the application binary. Server-side jobs, profiles, messages and other data can update without publishing a new APK. Binary updates require a new Play release and are delivered through Google Play's supported update mechanism.
