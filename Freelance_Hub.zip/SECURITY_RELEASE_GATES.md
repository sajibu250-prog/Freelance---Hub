# Freelance Hub — Production Security Gates

These are release blockers, not optional enhancements.

- [ ] Authentication provider configured; passwords handled only by trusted auth service.
- [ ] Access tokens short-lived; refresh tokens rotated/revoked server-side.
- [ ] Every write checks authenticated user identity and server-side role/ownership.
- [ ] Client-submitted role, price, status and ownership fields are never trusted.
- [ ] HTTPS only; certificate/network security configured for release builds.
- [ ] Secrets, payment keys and admin credentials exist only on trusted backend infrastructure.
- [ ] Rate limits and abuse controls enabled for auth, jobs, proposals and messages.
- [ ] Payment webhooks verified server-side before Premium entitlement is granted.
- [ ] Idempotency keys used for money-moving and duplicate-sensitive operations.
- [ ] Account deletion/data export and privacy/terms flows implemented.
- [ ] Report/block/moderation flow implemented before public marketplace launch.
- [ ] Database backups, audit logs and monitoring configured.
- [ ] Unit, UI, integration and security tests pass on release candidate.
- [ ] Signed AAB/APK build reproduced and smoke-tested on supported Android versions.
