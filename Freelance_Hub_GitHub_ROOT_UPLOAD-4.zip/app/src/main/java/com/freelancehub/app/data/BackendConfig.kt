package com.freelancehub.app.data

/**
 * Production backend configuration is intentionally injected at build/deployment time.
 * Never place service secrets, private keys, or admin credentials in the Android APK.
 */
data class BackendConfig(
    val baseUrl: String,
    val projectId: String,
    val environment: String = "production"
) {
    fun isConfigured(): Boolean = baseUrl.isNotBlank() && projectId.isNotBlank()
}


object RuntimeBackendConfig {
    fun fromBuildConfig(): BackendConfig = BackendConfig(
        baseUrl = com.freelancehub.app.BuildConfig.BACKEND_BASE_URL,
        projectId = com.freelancehub.app.BuildConfig.BACKEND_PROJECT_ID,
        environment = com.freelancehub.app.BuildConfig.BACKEND_ENVIRONMENT
    )
}
