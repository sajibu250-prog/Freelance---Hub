package com.freelancehub.app.data

import com.freelancehub.app.network.SecureApiClient
import com.freelancehub.app.security.TokenStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/** Auth adapter used when a real HTTPS backend is configured at build time. */
class RemoteAuthRepository(
    private val client: SecureApiClient,
    private val tokenStore: TokenStore
) : AuthRepository {
    override suspend fun signIn(request: AuthRequest): Result<AuthResponse> = authenticate(ApiContract.LOGIN, request)

    override suspend fun signUp(request: AuthRequest): Result<AuthResponse> = authenticate(ApiContract.SIGNUP, request)

    suspend fun refresh(): Result<AuthResponse> = withContext(Dispatchers.IO) {
        runCatching {
            val refresh = tokenStore.readRefreshToken() ?: error("Refresh session unavailable")
            val body = JSONObject().put("refreshToken", refresh).toString().toByteArray(Charsets.UTF_8)
            val connection = client.openJsonPost(ApiContract.REFRESH, body)
            val response = client.readResponse(connection); connection.disconnect()
            if (response.statusCode !in 200..299) error("Session refresh failed (${response.statusCode})")
            val data = (JSONObject(response.body).optJSONObject("data") ?: JSONObject(response.body))
            val result = AuthResponse(data.getString("accessToken"), data.getString("userId"), data.optString("role", "FREELANCER"), data.optLong("expiresAtEpochSeconds").takeIf { it > 0 }, data.getString("refreshToken"))
            tokenStore.saveAccessToken(result.accessToken, result.expiresAtEpochSeconds); tokenStore.saveRefreshToken(result.refreshToken!!); result
        }
    }

    override suspend fun signOut(): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val connection = client.openJsonPost(ApiContract.LOGOUT, "{}".toByteArray(), tokenStore.readAccessToken())
            val response = client.readResponse(connection)
            connection.disconnect()
            if (response.statusCode !in 200..299) error("Sign out failed (${response.statusCode})")
            tokenStore.clear()
        }
    }

    private suspend fun authenticate(path: String, request: AuthRequest): Result<AuthResponse> = withContext(Dispatchers.IO) {
        runCatching {
            val body = JSONObject().apply {
                put("email", request.email.trim())
                put("password", request.password)
                put("role", request.role)
                request.name?.trim()?.takeIf { it.isNotEmpty() }?.let { put("name", it) }
            }.toString().toByteArray(Charsets.UTF_8)
            val connection = client.openJsonPost(path, body, idempotencyKey = SecureApiClient.newIdempotencyKey())
            val response = client.readResponse(connection)
            connection.disconnect()
            if (response.statusCode !in 200..299) {
                val message = runCatching { JSONObject(response.body).optString("message") }.getOrNull().orEmpty()
                error(if (message.isNotBlank()) message else "Authentication failed (${response.statusCode})")
            }
            val json = JSONObject(response.body)
            val data = json.optJSONObject("data") ?: json
            val token = data.getString("accessToken")
            val result = AuthResponse(
                accessToken = token,
                userId = data.getString("userId"),
                role = data.optString("role", request.role),
                expiresAtEpochSeconds = data.optLong("expiresAtEpochSeconds").takeIf { it > 0 },
                refreshToken = data.optString("refreshToken").takeIf { it.isNotBlank() }
            )
            tokenStore.saveAccessToken(result.accessToken, result.expiresAtEpochSeconds)
            result.refreshToken?.let(tokenStore::saveRefreshToken)
            result
        }
    }
}
