package com.freelancehub.app.data

enum class UserRole { FREELANCER, CLIENT }

object JobStatus { const val OPEN = "Open"; const val PAUSED = "Paused"; const val CLOSED = "Closed" }
object ProposalStatus { const val SUBMITTED = "Submitted"; const val SHORTLISTED = "Shortlisted"; const val ACCEPTED = "Accepted"; const val REJECTED = "Rejected" }

data class Job(
    val id:Int,
    val title:String,
    val client:String,
    val budget:String,
    val skills:String,
    val description:String="",
    val remote:Boolean=true,
    val status:String=JobStatus.OPEN,
    val createdAt:Long=System.currentTimeMillis()
)

data class Proposal(
    val jobId:Int,
    val coverLetter:String,
    val bid:String,
    val delivery:String,
    val status:String=ProposalStatus.SUBMITTED,
    val createdAt:Long=System.currentTimeMillis()
)

data class UserProfile(
    val name:String="",
    val email:String="",
    val bio:String="",
    val skills:String="",
    val role:UserRole=UserRole.FREELANCER
)
