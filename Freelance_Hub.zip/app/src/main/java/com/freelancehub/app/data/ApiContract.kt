package com.freelancehub.app.data

/** Provider-neutral contract; the Android client must never contain admin/service secrets. */
object ApiContract {
    const val API_VERSION = "v1"
    const val LOGIN = "/$API_VERSION/auth/login"
    const val SIGNUP = "/$API_VERSION/auth/signup"
    const val REFRESH = "/$API_VERSION/auth/refresh"
    const val LOGOUT = "/$API_VERSION/auth/logout"
    const val JOBS = "/$API_VERSION/jobs"
    const val JOB_BY_ID = "/$API_VERSION/jobs/{jobId}"
    const val PROPOSALS = "/$API_VERSION/proposals"
    const val PROPOSAL_STATUS = "/$API_VERSION/proposals/{jobId}/status"
    const val MESSAGES = "/$API_VERSION/messages"
    const val PROFILE = "/$API_VERSION/profile"
    const val NOTIFICATIONS = "/$API_VERSION/notifications"
}

data class AuthRequest(val email:String,val password:String,val role:String="FREELANCER",val name:String?=null)
data class AuthResponse(val accessToken:String,val userId:String,val role:String, val expiresAtEpochSeconds:Long?=null)
