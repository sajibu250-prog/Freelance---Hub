package com.freelancehub.app.network

import com.freelancehub.app.data.ApiContract
import com.freelancehub.app.security.TokenStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject

/** Authenticated transport with single-flight refresh on 401 responses. */
class AuthenticatedApiClient(
    private val client: SecureApiClient,
    private val tokenStore: TokenStore
) {
    private val refreshMutex = Mutex()

    suspend fun get(path: String): ApiHttpResponse = withContext(Dispatchers.IO) {
        execute { client.openGet(path, tokenStore.readAccessToken()) }
    }

    suspend fun post(path: String, body: ByteArray, idempotencyKey: String? = null): ApiHttpResponse = withContext(Dispatchers.IO) {
        execute { client.openJsonPost(path, body, tokenStore.readAccessToken(), idempotencyKey) }
    }

    suspend fun patch(path: String, body: ByteArray): ApiHttpResponse = withContext(Dispatchers.IO) {
        execute { client.openJsonPatch(path, body, tokenStore.readAccessToken()) }
    }

    private suspend fun execute(open: () -> java.net.HttpURLConnection): ApiHttpResponse {
        val first = open().let { connection -> client.readResponse(connection).also { connection.disconnect() } }
        if (first.statusCode != 401) return first
        if (refreshAccessToken().isFailure) return first
        return open().let { connection -> client.readResponse(connection).also { connection.disconnect() } }
    }

    private suspend fun refreshAccessToken(): Result<Unit> = refreshMutex.withLock {
        runCatching {
            val refresh = tokenStore.readRefreshToken() ?: error("Refresh session unavailable")
            val body = JSONObject().put("refreshToken", refresh).toString().toByteArray(Charsets.UTF_8)
            val connection = client.openJsonPost(ApiContract.REFRESH, body)
            val response = client.readResponse(connection)
            connection.disconnect()
            if (response.statusCode !in 200..299) {
                tokenStore.clear()
                error("Session refresh failed (${response.statusCode})")
            }
            val data = JSONObject(response.body).optJSONObject("data") ?: JSONObject(response.body)
            val access = data.getString("accessToken")
            val rotatedRefresh = data.optString("refreshToken").takeIf { it.isNotBlank() }
            tokenStore.saveAccessToken(access)
            rotatedRefresh?.let(tokenStore::saveRefreshToken)
        }
    }
}
