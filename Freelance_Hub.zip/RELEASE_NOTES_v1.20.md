# Freelance Hub v1.20 — Consolidated Release Hardening

This release consolidates the current Android foundation and prepares it for the real backend/release phase.

## Changes
- Version bumped to 0.20.0 / versionCode 20.
- Explicit Android cleartext-traffic prohibition via Network Security Config.
- Release build enables R8 shrinking/resource shrinking with a project ProGuard file.
- Preserves official Google Play In-App Update flow.
- Preserves secure token storage and HTTPS API foundation.
- Keeps backend PostgreSQL schema/RLS and OpenAPI contracts separate from the Android client.

## Important
This is still not a signed production APK/AAB. Google Play update behavior only becomes active after the app is published and a newer Play release is available.
